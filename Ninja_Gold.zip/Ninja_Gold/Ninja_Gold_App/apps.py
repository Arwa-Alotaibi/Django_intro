from django.apps import AppConfig


class NinjaGoldAppConfig(AppConfig):
    name = 'Ninja_Gold_App'
